# Inventory Management System
Open source inventory management system with php and mysql
Invoice generation and easy to download invoice in PDF format
Lightweight and easy to use
Order management and product management can be done with ease
Report management
User wise sell report
#Requirement
Need to change
core.php, logout.php, index.php
header('location: http://localhost/<foldername>/index.php');	

